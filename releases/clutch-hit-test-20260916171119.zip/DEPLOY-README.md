# CLUTCH HIT 회사 테스트 배포

## 서버에 올리기

1. ZIP을 압축 해제합니다. 최상위에 index.html, app.js, styles.css, assets/, vendor/가 있습니다.
2. 압축 해제한 내용을 회사 정적 웹서버의 테스트 경로에 그대로 업로드합니다.
3. https://테스트서버/baseball/ 처럼 폴더 URL 끝에 /를 붙여 접속합니다. 웹서버 기본 문서는 index.html로 지정합니다.

루트 경로와 하위 폴더 모두 지원합니다. 폴더 구조를 유지하세요. 파일을 하나씩 섞어 올리지 말고 같은 ZIP 전체를 함께 배포하세요. 서버에서 npm 설치, 빌드 또는 Node.js 실행은 필요하지 않습니다. 외부 CDN이나 Google Fonts 접속 없이 포함된 파일만으로 동작합니다.

## 서버 설정

- HTTP/HTTPS 정적 파일 서비스로 실행하세요. index.html 파일을 직접 더블클릭하는 file:// 방식에서는 효과음 로딩이 제한될 수 있습니다.
- MIME: .html text/html, .js text/javascript, .css text/css, .png image/png, .mp3 audio/mpeg, .ttf font/ttf.
- 테스트 업데이트 후 이전 파일이 보이면 브라우저/서버 캐시를 갱신하세요. 테스트 중 index.html은 Cache-Control: no-cache 설정을 권장합니다.
- 별도 API, 데이터베이스, SPA 라우팅 설정은 필요하지 않습니다.
- 회사 서버가 엄격한 CSP를 적용한다면 동일 출처의 스크립트·스타일·이미지·폰트·음원과 인라인 SVG 조명 필터 및 게임이 갱신하는 스타일 속성이 차단되지 않는지 확인하세요. favicon은 data: SVG를 사용합니다.

## 최신 UI 및 그래픽 변경

- CLUTCH HIT 타이틀, 상단 정보 정렬 및 확대된 배수 숫자.
- 모바일 설정 패널 64px, 화면 높이에 맞춘 경기장과 버튼 배치.
- HOW TO PLAY 닫기 버튼 가독성 및 터치 영역 확대.
- 성공 칸은 야구공 PNG만 표시하며 최초 아이콘 크기의 70% 적용.
- 배트의 과한 노란빛을 줄인 밝은 베이지색 나무 재질.

## 포함된 오디오 수정

모바일에서 HIT가 약하거나 짧게 들리는 현상에 맞춰 중음역과 잔향을 보강하고 순간 피크를 제한했습니다. PC/터치 에뮬레이션 검증은 완료했으며 실제 안드로이드에서 재확인하세요. 전체 ZIP을 다시 올린 뒤 새로고침해 이전 app.js 캐시가 남지 않도록 합니다.

## 테스트 항목

- 첫 버튼 조작 후 음악 재생. 인트로 15%, 경기 BGM 16%, 마스터 80%.
- ? → GAME SETTINGS → GAME TIME에서 DAY GAME / NIGHT GAME 전환. 새로고침 후 선택 유지.
- 베팅 설정 → 타격존 선택 → HIT/OUT → CASH OUT/NEXT ROUND.
- 소리 버튼 음소거 및 설정 유지. 모바일 화면 크기와 브라우저 UI 변화에 따른 하단 버튼 표시 확인.

## 테스트 빌드 범위

현재 HTML/JavaScript POC이며 가상 크레딧으로 동작합니다. 회사 계정·실제 정산 서버와의 연동은 포함하지 않습니다. 새로고침하면 라운드/잔액은 초기화되고, 낮·밤 및 음소거 설정만 브라우저에 저장됩니다.

THIRD-PARTY.md 및 assets/fonts/*-license.txt, vendor/*LICENSE.txt에 출처와 라이선스가 포함됩니다. source-assets 및 개발용 .work, .git, 원본 개발 문서는 배포물에 포함하지 않습니다.

패키지: clutch-hit-test-20260916171119
빌드 시각(UTC): 2026-09-16T08:11:19.204Z
SHA256SUMS.txt: 각 배포 파일의 SHA-256 체크섬(자기 자신 제외).
